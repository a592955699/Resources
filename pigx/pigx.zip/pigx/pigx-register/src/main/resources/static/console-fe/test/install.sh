#!/usr/bin/env bash
ls ~/nvm || git clone https://github.com/creationix/nvm.git ~/nvm
source ~/nvm/nvm.sh
nvm install v7.10.0
npm install
